=== Login Magician ===
Contributors: gurjotsinghdev
Tags: wp-login, login page customize
Donate link: http://gurjotsinghdev.vercel.app
Requires at least: 4.0
Tested up to: 4.8
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Are you looking to give a fresh and fun look to your WP Login page.
Login Magician provivdes a fresh background images to your login page,
It changes to a new images everytime you visit the page randonly. 
The plugin is very lightweight with no settings, simple plug n play.



== Changelog ==

= 1.0.0 =
* Initial release.


